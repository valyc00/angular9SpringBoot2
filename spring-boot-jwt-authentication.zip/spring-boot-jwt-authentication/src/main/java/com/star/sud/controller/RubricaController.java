package com.star.sud.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.star.sud.request.LoginRequest;
import com.star.sud.request.SignupRequest;
import com.star.sud.rubrica.model.Rubrica;
import com.star.sud.service.IAuthService;
import com.star.sud.service.impl.IRubricaService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/rubrica")
public class RubricaController {

	@Autowired
	private IRubricaService rubricaService;

	@GetMapping("/rub")
	public ResponseEntity<?> findAll() {
		List<Rubrica> findAll = rubricaService.findAll();
		
		
		return new ResponseEntity<>(findAll, HttpStatus.OK);
	}

	
}
