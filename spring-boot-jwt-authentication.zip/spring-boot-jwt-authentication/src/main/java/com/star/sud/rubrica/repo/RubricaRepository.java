package com.star.sud.rubrica.repo;



import org.springframework.data.jpa.repository.JpaRepository;

import com.star.sud.rubrica.model.Rubrica;


public interface RubricaRepository extends JpaRepository<Rubrica, Long> {

	

}

