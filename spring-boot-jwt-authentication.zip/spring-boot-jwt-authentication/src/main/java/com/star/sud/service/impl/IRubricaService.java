package com.star.sud.service.impl;

import java.util.List;

import com.star.sud.rubrica.model.Rubrica;

public interface IRubricaService {

	List<Rubrica> findAll();

}