package com.star.sud.service.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.star.sud.request.LoginRequest;
import com.star.sud.request.MessageResponse;
import com.star.sud.request.SignupRequest;
import com.star.sud.rubrica.model.Rubrica;
import com.star.sud.rubrica.repo.RubricaRepository;
import com.star.sud.security.jjwt.JwtUtils;
import com.star.sud.security.request.JwtResponse;
import com.star.sud.security.service.UserDetailsImpl;
import com.star.sud.service.IAuthService;
import com.star.sud.user.model.ERole;
import com.star.sud.user.model.Role;
import com.star.sud.user.model.User;
import com.star.sud.user.repo.RoleRepositiry;
import com.star.sud.user.repo.UserRepository;

@Service
public class RubricaServiceImpl implements IRubricaService  {

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	RubricaRepository rubricaRepository;

	

	@Autowired
	JwtUtils jwtUtils;

	@Override
	public List<Rubrica> findAll() {
		List<Rubrica> findAll = rubricaRepository.findAll();
		
		return findAll;
	}

	
}
